public class Pago extends Estado{
    public Pago() {
        super();
    }

    @Override
    public Estado arquiva() {
        return new Fim();
    }
}
