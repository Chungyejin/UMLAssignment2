public class Faturado extends Estado {
    public Faturado() {
        super();
    }

    @Override
    public Estado paga() {
        return new Pago();
    }

    @Override
    public Estado arquiva() {
        return new Fim();
    }
}