public class Encomendado extends Estado {
    public Encomendado() {
        super();
    }

    @Override
    public Estado entrega() {
        return new Faturado();
    }

    @Override
    public Estado cancela() {
        return new Cancelado();
    }
}
