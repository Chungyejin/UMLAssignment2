public class Fim extends Estado {
    public Fim() {
        super();
    }
}
