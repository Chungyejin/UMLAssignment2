package composite.modelo.produtos;

import composite.modelo.Folha;

public class Bebida extends Folha {
    public Bebida(String nm) {
        super(nm);
    }
}
