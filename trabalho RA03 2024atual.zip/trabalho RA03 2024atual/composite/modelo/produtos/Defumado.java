package composite.modelo.produtos;

import composite.modelo.Folha;

public class Defumado extends Folha {
    public Defumado(String nm) {
        super(nm);
    }
}
