package composite.modelo.produtos;

import composite.modelo.Folha;

public class Carne extends Folha {
    public Carne(String nm) {
        super(nm);
    }
}
