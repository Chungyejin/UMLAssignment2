package composite.modelo.produtos;

public class Composite1 {

    public static void execute(){
        CategoriaRaiz CRaiz = new CategoriaRaiz("Categoria Raiz");
        
        Categoria comestivel = new Categoria("Categoria de Comestíveis");

        Categoria diversos = new Categoria("Categoria Diversos");

        CategoriaFolha cereal = new CategoriaFolha("Cereais");
        diversos.adicionar(cereal);
        cereal.adicionar(new Cereal("Nescau Ball"));
        cereal.adicionar(new Cereal("Sucrilhos Kellogs"));
        cereal.adicionar(new Cereal("Aveia Quaker"));

        CategoriaFolha bebida = new CategoriaFolha("Bebidas");
        diversos.adicionar(bebida);
        bebida.adicionar(new Bebida("Nesquik"));
        bebida.adicionar(new Bebida("51 (você sabe qual)"));
        bebida.adicionar(new Bebida("Caipirinha Limão Rosa"));

        Categoria proteinaAnimal = new Categoria("Categoria de Proteína Animal");

        CategoriaFolha defumado = new CategoriaFolha("Defumados");
        defumado.adicionar(new Defumado("Linguiça Blumenau (defumada)"));
        defumado.adicionar(new Defumado("Prosciutto"));
        defumado.adicionar(new Defumado("Salamitos"));

        CategoriaFolha carne = new CategoriaFolha("Carnes");
        carne.adicionar(new Carne("Cupim"));
        carne.adicionar(new Carne("Mignon"));
        carne.adicionar(new Carne("Pé de galinha"));

        proteinaAnimal.adicionar(defumado);
        proteinaAnimal.adicionar(carne);
        comestivel.adicionar(diversos);
        comestivel.adicionar(proteinaAnimal);

        CategoriaFolha limpeza = new CategoriaFolha("Categoria Limpeza");

        limpeza.adicionar(new Limpeza("Vassoura"));
        limpeza.adicionar(new Limpeza("X14"));
        limpeza.adicionar(new Limpeza("Ozônio"));

        CRaiz.adicionar(comestivel);
        CRaiz.adicionar(limpeza);

        CRaiz.listar(0);
    }
}
