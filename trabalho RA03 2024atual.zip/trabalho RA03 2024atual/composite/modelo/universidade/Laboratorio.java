package composite.modelo.universidade;

import composite.modelo.Folha;

public class Laboratorio extends Folha {
    public Laboratorio(String nm) {
        super(nm);
    }
}
