package composite.modelo.universidade;

import composite.modelo.produtos.Composite1;

public class Composite2 {

    public static void execute(){

        Universidade universidade = new Universidade("Universidade");
        Campus curitiba = new Campus("Curitiba");

        Bloco azul = new Bloco("Bloco Azul");
        Bloco verde = new Bloco("Verde Bloco");

        Andar primeiro = new Andar("Primeiro andar");
        Andar segundo = new Andar("Segundo andar");

        primeiro.adicionar(new Corredor("Corredor P1"));
        primeiro.adicionar(new Sala("Sala P2"));
        primeiro.adicionar(new Sala("Sala P3"));

        segundo.adicionar(new Corredor("Corredor P4"));
        segundo.adicionar(new Sala("Sala P5"));
        segundo.adicionar(new Laboratorio("Laboratório P6"));

        azul.adicionar(primeiro);
        azul.adicionar(segundo);

        Andar terceiro = new Andar("Terceiro andar");
        Andar quarto = new Andar("Quarto andar");

        terceiro.adicionar(new Laboratorio("Laboratório P7"));
        terceiro.adicionar(new Auditorio("Auditório P8"));
        terceiro.adicionar(new Cantina("Cantina P9"));

        quarto.adicionar(new Sala("Sala P10"));
        quarto.adicionar(new Sala("Sala P11"));
        quarto.adicionar(new Laboratorio("Laboratório P12"));

        verde.adicionar(terceiro);
        verde.adicionar(quarto);

        curitiba.adicionar(azul);
        curitiba.adicionar(verde);

        Campus londrina = new Campus("Londrina");

        londrina.adicionar(new Auditorio("Auditório L1"));
        londrina.adicionar(new Sala("Sala L2"));
        londrina.adicionar(new Laboratorio("Laboratório L3"));

        universidade.adicionar(curitiba);
        universidade.adicionar(londrina);

        universidade.listar(0);
    }
}
