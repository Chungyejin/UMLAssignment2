package composite.modelo.universidade;

import composite.modelo.Composicao;

public class Universidade extends Composicao {
    public Universidade(String nm) {
        super(nm);
    }
}
