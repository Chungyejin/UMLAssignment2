package composite.modelo.universidade;

import composite.modelo.Folha;

public class Sala extends Folha {
    public Sala(String nm) {
        super(nm);
    }
}
