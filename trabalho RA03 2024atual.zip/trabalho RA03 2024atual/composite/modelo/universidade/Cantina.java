package composite.modelo.universidade;

import composite.modelo.Folha;

public class Cantina extends Folha {
    public Cantina(String nm) {
        super(nm);
    }
}
