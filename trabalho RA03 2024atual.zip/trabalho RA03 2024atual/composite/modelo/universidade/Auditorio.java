package composite.modelo.universidade;

import composite.modelo.Folha;

public class Auditorio extends Folha {
    public Auditorio(String nm) {
        super(nm);
    }
}
