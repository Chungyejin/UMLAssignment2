package composite.modelo.portifolio;

import composite.modelo.Composicao;

public class Projeto extends Composicao {
    public Projeto(String nm) {
        super(nm);
    }
}
