package composite.modelo.portifolio;

import composite.modelo.Composicao;

public class Atividade extends Composicao {
    public Atividade(String nm) {
        super(nm);
    }
}
