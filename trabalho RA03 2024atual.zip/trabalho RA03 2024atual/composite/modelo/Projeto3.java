package composite.modelo;

import composite.modelo.portifolio.Composite3;
import composite.modelo.produtos.Composite1;
import composite.modelo.universidade.Composite2;

public class Projeto3 {
    public static void main(String [] args){

        Composite1.execute();
        System.out.println("\n--------------------------------------------------------\n");
        Composite2.execute();
        System.out.println("\n--------------------------------------------------------\n");
        Composite3.execute();

    }}
