package composite.pgarquivo;

import composite.modelo.Composicao;

public class PastaRaiz extends Composicao {

    public PastaRaiz(String nm){
        super(nm);
    }
}
