package composite.modelo;

public class Defumado extends Folha{
    public Defumado(String nm) {
        super(nm);
    }
}
