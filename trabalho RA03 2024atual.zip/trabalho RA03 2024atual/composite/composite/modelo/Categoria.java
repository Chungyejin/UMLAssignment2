package composite.modelo;

public class Categoria extends Composicao{
    public Categoria(String nm) {
        super(nm);
    }
}
