package composite.modelo;

public abstract class Folha extends Elemento { //herda a classe Elemento

        public Folha(String nm){
            super(nm);
        }
        
        @Override
        public boolean adicionar(Elemento d) throws MyException { //não é possível adicionar a folha
            throw (new MyException("Operacao não valida em Folha"));
        }
        
        @Override
        public Elemento excluir(String nm) throws MyException {
                throw (new MyException("Operacao não valida em Folha")); //não é possível excluir
            }

            @Override
                public Elemento consultar(String nome) throws MyException{
                throw (new MyException("Operacao não valida em Folha")); //não é possível consultar
            }

            @Override
            public void listar(int nivel){ //listar pelo folha
                tabular(nivel); //indentar folha
            }
}
