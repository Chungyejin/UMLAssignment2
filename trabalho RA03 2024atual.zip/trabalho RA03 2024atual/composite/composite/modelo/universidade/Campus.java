package composite.modelo.universidade;

import composite.modelo.Composicao;

public class Campus extends Composicao {
    public Campus(String nm) {
        super(nm);
    }
}
