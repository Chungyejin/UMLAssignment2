package composite.modelo.universidade;

import composite.modelo.Elemento;
import composite.modelo.produtos.Composite1;

public class Composite2 {

    public static Elemento criarInstancias(){

        Universidade universidade = new Universidade("Universidade");
        Campus curitiba = new Campus("Curitiba");

        Bloco azul = new Bloco("Bloco Azul");
        Bloco verde = new Bloco("Bloco Verde");

        Andar primeiro = new Andar("Primeiro andar");
        Andar segundo = new Andar("Segundo andar");

        Andar terceiro = new Andar("Terceiro andar");
        Andar quarto = new Andar("Quarto andar");

        Campus londrina = new Campus("Londrina");

        primeiro.adicionar(new Corredor("P1"));
        primeiro.adicionar(new Sala("P2"));
        primeiro.adicionar(new Sala("P3"));

        segundo.adicionar(new Corredor("P4"));
        segundo.adicionar(new Sala("P5"));
        segundo.adicionar(new Laboratorio("P6"));

        azul.adicionar(primeiro);
        azul.adicionar(segundo);

        terceiro.adicionar(new Laboratorio("P7"));
        terceiro.adicionar(new Auditorio("P8"));
        terceiro.adicionar(new Cantina("P9"));

        quarto.adicionar(new Sala("P10"));
        quarto.adicionar(new Sala("P11"));
        quarto.adicionar(new Laboratorio("P12"));

        verde.adicionar(terceiro);
        verde.adicionar(quarto);

        curitiba.adicionar(azul);
        curitiba.adicionar(verde);

        londrina.adicionar(new Auditorio("L1"));
        londrina.adicionar(new Sala("L2"));
        londrina.adicionar(new Laboratorio("L3"));

        universidade.adicionar(curitiba);
        universidade.adicionar(londrina);

        return universidade;
    }

    public static void execute(){
        Elemento pRaiz = criarInstancias();
        pRaiz.listar(0);

    }
}
