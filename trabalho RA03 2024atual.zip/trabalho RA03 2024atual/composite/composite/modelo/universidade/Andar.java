package composite.modelo.universidade;

import composite.modelo.Composicao;

public class Andar extends Composicao {
    public Andar(String nm) {
        super(nm);
    }

}
