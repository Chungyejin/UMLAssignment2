package composite.modelo.universidade;

import composite.modelo.Composicao;

public class Bloco extends Composicao {
    public Bloco(String nm) {
        super(nm);
    }

}
