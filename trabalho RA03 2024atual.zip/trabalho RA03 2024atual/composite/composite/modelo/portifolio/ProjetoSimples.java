package composite.modelo.portifolio;

import composite.modelo.Elemento;

public class ProjetoSimples extends Projeto {
     public ProjetoSimples(String nm) {
        super(nm);
    }

    @Override
    public void listar(int nivel) {
        tabular(nivel); // Método para criar a indentação
        System.out.println("Projeto Simples: " + this.nome); // Exibe o nome do elemento atual
        // Chama o método listar para cada elemento filho, incrementando o nível de indentação
        for (Elemento e : this.elemento) {
            e.listar(nivel + 1);
        }
    }
}
