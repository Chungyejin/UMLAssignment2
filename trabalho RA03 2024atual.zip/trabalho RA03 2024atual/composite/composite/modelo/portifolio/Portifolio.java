package composite.modelo.portifolio;

import composite.modelo.Composicao;

public class Portifolio extends Composicao {
    public Portifolio(String nm) {
        super(nm);
    }
}
