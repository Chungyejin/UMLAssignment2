package composite.modelo;

public class Carne extends Folha{
    public Carne(String nm) {
        super(nm);
    }
}
