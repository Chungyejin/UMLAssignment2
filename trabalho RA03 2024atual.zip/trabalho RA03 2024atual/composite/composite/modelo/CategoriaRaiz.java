package composite.modelo;

public class CategoriaRaiz extends Categoria{
    public CategoriaRaiz(String nm) {
        super(nm);
    }
}
