package composite.modelo;

import composite.modelo.portifolio.Composite3;
import composite.modelo.produtos.Composite1;
import composite.modelo.universidade.Composite2;

public class Projeto3 {
    public static void main(String [] args){
        System.out.println("\n---------------Categoria---------------\n");
        Composite1.execute();
        System.out.println("\n---------------Universidade---------------\n");
        Composite2.execute();
        System.out.println("\n---------------Portifólio---------------\n");
        Composite3.execute();

    }}
