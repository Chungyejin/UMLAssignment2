package composite.modelo;

public class Projeto3 {

    public static void execute(){
        CategoriaRaiz CRaiz = new CategoriaRaiz("Categoria Raiz");
        
        Categoria comestivel = new Categoria("Categoria de Comestíveis");
        CRaiz.adicionar(comestivel); //CRaiz contém comestivel

        CategoriaFolha limpeza = new CategoriaFolha("Categoria Limpeza");
        CRaiz.adicionar(limpeza); //CRaiz contém limpeza

        limpeza.adicionar(new Limpeza("Vassoura"));
        limpeza.adicionar(new Limpeza("X14"));
        limpeza.adicionar(new Limpeza("Ozônio"));

        Categoria diversos = new Categoria("Categoria Diversos");
        comestivel.adicionar(diversos);  //Comestível contém diversos
        
        Categoria proteinaAnimal = new Categoria("Categoria de Proteína Animal");
        comestivel.adicionar(proteinaAnimal); //Comestível contém proteína animal
        
        CategoriaFolha cereal = new CategoriaFolha("Cereais");
        diversos.adicionar(cereal); //diversos contém categoria cereal
        cereal.adicionar(new Cereal("Nescau Ball"));
        cereal.adicionar(new Cereal("Sucrilhos Kellogs"));
        cereal.adicionar(new Cereal("Aveia Quaker"));
        
        CategoriaFolha bebida = new CategoriaFolha("Bebidas");
        diversos.adicionar(bebida); //diversos contém bebida
        bebida.adicionar(new Bebida("Nesquik"));
        bebida.adicionar(new Bebida("51 (você sabe qual)"));
        bebida.adicionar(new Bebida("Caipirinha Limão Rosa"));

        CategoriaFolha defumado = new CategoriaFolha("Defumados");
        proteinaAnimal.adicionar(defumado); //proteína animal contém defumado
        defumado.adicionar(new Defumado("Linguiça Blumenau (defumada)"));
        defumado.adicionar(new Defumado("Prosciutto"));
        defumado.adicionar(new Defumado("Salamitos"));

        CategoriaFolha carne = new CategoriaFolha("Carnes");
        proteinaAnimal.adicionar(carne); //proteína animal contém carne
        carne.adicionar(new Carne("Cupim"));
        carne.adicionar(new Carne("Mignon"));
        carne.adicionar(new Carne("Pé de galinha"));

        CRaiz.listar(0);
    }

    public static void main(String [] args){
        Projeto3.execute();
    }
}
