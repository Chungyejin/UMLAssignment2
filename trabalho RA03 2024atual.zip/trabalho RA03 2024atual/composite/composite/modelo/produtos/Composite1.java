package composite.modelo.produtos;

import composite.modelo.Elemento;

public class Composite1 {

    public static Elemento criarInstancias(){
        CategoriaRaiz CRaiz = new CategoriaRaiz("Categoria Raiz");
        
        Categoria comestivel = new Categoria("Categoria de Comestíveis");

        Categoria diversos = new Categoria("Categoria Diversos");

        CategoriaFolha cereal = new CategoriaFolha("Cereais");

        CategoriaFolha bebida = new CategoriaFolha("Bebidas");

        Categoria proteinaAnimal = new Categoria("Categoria de Proteína Animal");

        CategoriaFolha defumado = new CategoriaFolha("Defumados");

        CategoriaFolha carne = new CategoriaFolha("Carnes");

        CategoriaFolha limpeza = new CategoriaFolha("Categoria Limpeza");

        cereal.adicionar(new Cereal("Nescau Ball"));
        cereal.adicionar(new Cereal("Sucrilhos Kellogs"));
        cereal.adicionar(new Cereal("Aveia Quaker"));

        bebida.adicionar(new Bebida("Nesquik"));
        bebida.adicionar(new Bebida("51 (você sabe qual)"));
        bebida.adicionar(new Bebida("Caipirinha Limão Rosa"));

        defumado.adicionar(new Defumado("Linguiça Blumenau (defumada)"));
        defumado.adicionar(new Defumado("Prosciutto"));
        defumado.adicionar(new Defumado("Salamitos"));

        carne.adicionar(new Carne("Cupim"));
        carne.adicionar(new Carne("Mignon"));
        carne.adicionar(new Carne("Pé de galinha"));

        limpeza.adicionar(new Limpeza("Vassoura"));
        limpeza.adicionar(new Limpeza("X14"));
        limpeza.adicionar(new Limpeza("Ozônio"));

        diversos.adicionar(cereal);
        diversos.adicionar(bebida);

        proteinaAnimal.adicionar(defumado);
        proteinaAnimal.adicionar(carne);

        comestivel.adicionar(diversos);
        comestivel.adicionar(proteinaAnimal);

        CRaiz.adicionar(comestivel);
        CRaiz.adicionar(limpeza);

        return CRaiz;
    }

    public static void execute(){
        Elemento pRaiz = criarInstancias();
        pRaiz.listar(0);

    }
}
