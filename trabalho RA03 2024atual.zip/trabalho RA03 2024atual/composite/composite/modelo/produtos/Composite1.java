package composite.modelo.produtos;

import composite.modelo.Elemento;
import composite.modelo.MyException;

public class Composite1 {

    public static Elemento criarInstancias(){
        CategoriaRaiz CRaiz = new CategoriaRaiz("Categoria Raiz");
        
        Categoria comestivel = new Categoria("Categoria de Comestíveis");

        Categoria diversos = new Categoria("Categoria Diversos");

        CategoriaFolha cereal = new CategoriaFolha("Cereais");

        CategoriaFolha bebida = new CategoriaFolha("Bebidas");

        Categoria proteinaAnimal = new Categoria("Categoria de Proteína Animal");

        CategoriaFolha defumado = new CategoriaFolha("Defumados");

        CategoriaFolha carne = new CategoriaFolha("Carnes");

        CategoriaFolha limpeza = new CategoriaFolha("Categoria Limpeza");

        cereal.adicionar(new Cereal("P1"));
        cereal.adicionar(new Cereal("P2"));
        cereal.adicionar(new Cereal("P3"));

        bebida.adicionar(new Bebida("P4"));
        bebida.adicionar(new Bebida("P5"));
        bebida.adicionar(new Bebida("P6"));

        defumado.adicionar(new Defumado("P7"));
        defumado.adicionar(new Defumado("P8"));
        defumado.adicionar(new Defumado("P9"));

        carne.adicionar(new Carne("P10"));
        carne.adicionar(new Carne("P11"));
        carne.adicionar(new Carne("P12"));

        limpeza.adicionar(new Limpeza("L1"));
        limpeza.adicionar(new Limpeza("L2"));
        limpeza.adicionar(new Limpeza("L3"));

        diversos.adicionar(cereal);
        diversos.adicionar(bebida);

        proteinaAnimal.adicionar(defumado);
        proteinaAnimal.adicionar(carne);

        comestivel.adicionar(diversos);
        comestivel.adicionar(proteinaAnimal);

        CRaiz.adicionar(comestivel);
        CRaiz.adicionar(limpeza);

        return CRaiz;
    }

    public static void execute() {

        try {
            Elemento pRaiz = criarInstancias();
            pRaiz.listar(0);

            System.out.println("\nApós uma inserção: \n");

            //Exemplo adicionar um elemento de em limpeza
            pRaiz.consultar("Categoria Limpeza").adicionar(new Limpeza("L4"));

            pRaiz.listar(0);

            System.out.println("\nApós uma deleção: \n");

            //Exemplo excluir um elemento de em limpeza
            pRaiz.excluir("L4");

            pRaiz.listar(0);

        }catch(MyException e){
            System.out.println( e.getMessage() );
        }
    }
}
