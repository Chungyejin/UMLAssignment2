package composite.modelo.produtos;

import composite.modelo.Composicao;

public class Categoria extends Composicao {
    public Categoria(String nm) {
        super(nm);
    }
}
