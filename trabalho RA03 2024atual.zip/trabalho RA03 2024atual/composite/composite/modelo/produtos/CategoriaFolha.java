package composite.modelo.produtos;

public class CategoriaFolha extends Categoria {
    public CategoriaFolha(String nm) {
        super(nm);
    }

}
