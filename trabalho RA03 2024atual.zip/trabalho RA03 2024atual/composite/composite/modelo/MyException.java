
package composite.modelo;


public class MyException extends Exception{
    
    private String msg; //atributo msg que irá transmitir a exceção
    
    public MyException(String msg){
        super(msg);
    } //método MyExcepition para mostrar a exceção
}
