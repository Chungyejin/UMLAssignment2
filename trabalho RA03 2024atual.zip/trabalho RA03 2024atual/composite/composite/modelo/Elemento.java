package composite.modelo;

public abstract class Elemento {  //classe elemento

	protected String nome; //nome do elemento
	protected Elemento pertenceA; //ponteiro para o elemento que pertence
        
        public Elemento(String nm){
            this.nome = nm;
            this.pertenceA = null; //inicializando como null
        }

        public String getNome(){
            return nome;
        } //retona o nome
        
        public void pertenceA(Elemento pertenceA){
             this.pertenceA = pertenceA;           
        } //retone o ponteiro
 
        public Elemento pertenceA(){
             return this.pertenceA;           
        }
                
        protected void tabular(int k) { //função para indentação
            for (int i = 0; i < k; i++) {
                System.out.print("    ");
            }
        }  
        //Métodos abstratos que serão herdados
	abstract public Elemento consultar(String nome) throws MyException;
        abstract public boolean adicionar(Elemento d) throws MyException;
	abstract public Elemento excluir(String nm) throws MyException; 
	public abstract void listar(int nivel);

}
