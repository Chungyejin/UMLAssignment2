package composite.modelo;

public class Cereal extends Folha{
    public Cereal(String nm) {
        super(nm);
    }

}
