package com.ees.pp.State;

public class Fim extends Estado {
    public Fim() {
        super();
    }
}
