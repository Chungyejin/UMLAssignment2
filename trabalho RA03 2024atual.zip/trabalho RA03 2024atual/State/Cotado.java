package com.ees.pp.State;

public class Cotado extends Estado {

    public Cotado() {
        super();
    }

    @Override
    public Estado encomenda() {
        return new Encomendado();
    }

    @Override
    public Estado rejeita() {
        return new Rejeitado();
    }
}