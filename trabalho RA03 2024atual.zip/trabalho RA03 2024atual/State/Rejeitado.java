package com.ees.pp.State;

public class Rejeitado extends Estado{
    public Rejeitado() {
        super();
    }

    @Override
    public Estado arquiva() {
        return new Fim();
    }
}
