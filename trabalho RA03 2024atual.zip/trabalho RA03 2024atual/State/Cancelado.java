package com.ees.pp.State;

public class Cancelado extends Estado{
    public Cancelado() {
        super();
    }

    @Override
    public Estado arquiva() {
        return new Fim();
    }
}
