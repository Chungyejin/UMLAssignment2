
package interpretador.prefixada;

abstract public class Expressao
{
    abstract public double resolva();
    
    @Override
    abstract public String toString();


}
