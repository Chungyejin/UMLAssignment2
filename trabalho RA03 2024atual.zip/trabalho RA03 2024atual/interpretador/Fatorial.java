import java.util.ArrayList;

public class Fatorial extends Operador {


    public Fatorial(ArrayList<Expressao> elemento) {
        super(elemento);
    }

    @Override
    public char simbolo() {
        return '!';
    }

    private double faz() {
        double s = 1;
        for (Expressao e : this.elemento) {
            s = s * e.resolva();
        }
        return s;
    }

    @Override
    public double resolva() {
        double n = this.faz();
        double fatorial = 1;

        for (int i = 1; i <= n; i++) {
            fatorial *= i;
        }

        return fatorial;
    }
}



