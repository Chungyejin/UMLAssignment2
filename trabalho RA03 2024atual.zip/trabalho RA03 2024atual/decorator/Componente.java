
package com.ees.pp.decorator;

abstract interface Componente
{
   void desenha();
} 