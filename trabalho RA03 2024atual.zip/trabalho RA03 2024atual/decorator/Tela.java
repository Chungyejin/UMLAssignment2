

package com.ees.pp.decorator;

public class Tela implements Componente
{
    public void desenha() {
        System.out.println("TELA - ESSENCIA.");
    }
}