package composite.modelo.portifolio;

import composite.modelo.Elemento;
import composite.modelo.MyException;
import composite.modelo.produtos.Limpeza;

public class Composite3 {
    public static Elemento criarInstancias() {
        Portifolio pRaiz = new Portifolio("Portifolio");

        Projeto projeto1 = new Projeto("1");

        Projeto subprojeto1 = new Projeto("Subprojeto 1");

        Atividade atividade1 = new Atividade("1");
        Atividade atividade2 = new Atividade("2");

        Projeto subprojeto2 = new Projeto("Subprojeto 2");

        Atividade atividade8 = new Atividade("8");
        Atividade atividade9 = new Atividade("9");

        Projeto projeto2 = new ProjetoSimples("2");

        projeto2.adicionar(new Tarefa("TS1"));
        projeto2.adicionar(new Tarefa("TS2"));
        projeto2.adicionar(new Tarefa("TS3"));

        atividade1.adicionar(new Tarefa("T1"));
        atividade1.adicionar(new Tarefa("T2"));
        atividade1.adicionar(new Tarefa("T3"));

        atividade2.adicionar(new Tarefa("T4"));
        atividade2.adicionar(new Tarefa("T5"));
        atividade2.adicionar(new Tarefa("T6"));

        subprojeto1.adicionar(atividade1);
        subprojeto1.adicionar(atividade2);

        atividade8.adicionar(new Tarefa("T7"));
        atividade8.adicionar(new Tarefa("T8"));
        atividade8.adicionar(new Tarefa("T9"));

        atividade9.adicionar(new Tarefa("T10"));
        atividade9.adicionar(new Tarefa("T11"));
        atividade9.adicionar(new Tarefa("T12"));

        subprojeto2.adicionar(atividade8);
        subprojeto2.adicionar(atividade9);

        projeto1.adicionar(subprojeto1);
        projeto1.adicionar(subprojeto2);

        pRaiz.adicionar(projeto1);
        pRaiz.adicionar(projeto2);

        return pRaiz;
    }

    public static void execute(){
        try {
            Elemento pRaiz = criarInstancias();
            pRaiz.listar(0);

            System.out.println("\nApós uma inserção: \n");

            //Exemplo adicionar um elemento de em limpeza
            pRaiz.consultar("9").adicionar(new Tarefa("T13"));

            pRaiz.listar(0);

            System.out.println("\nApós uma deleção: \n");

            //Exemplo excluir um elemento de em limpeza
            pRaiz.excluir("T13");

            pRaiz.listar(0);
        }catch(MyException e){
            System.out.println( e.getMessage() );
        }

    }
}