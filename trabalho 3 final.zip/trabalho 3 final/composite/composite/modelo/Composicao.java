package composite.modelo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Stack;

public class Composicao extends Elemento {

    public ArrayList<Elemento> elemento;

    public Composicao(String nm) {
        super(nm);
        this.elemento = new ArrayList(); // inicialização da lista de elementos
    }

    @Override
    public boolean adicionar(Elemento d) {
        this.elemento.add(d);
        d.pertenceA(this); // define a composição pai do elemento adicionado
        return false;
    }

    @Override
    public Elemento consultar(String nm) throws MyException {

        Iterator<Elemento> itE = this.elemento.iterator();
        Stack<Elemento> pilha = new Stack();

        if (itE.hasNext()) {
            pilha.add(this); // adiciona o próprio objeto na pilha para iniciar a busca
        }

        Elemento ptr = null;
        // Realiza a busca até que a pilha esteja vazia
        while (!pilha.isEmpty()) {
            ptr = pilha.pop();
            if (ptr.nome.equals(nm)) { // verifica se o nome do elemento corresponde ao procurado
                return ptr;
            } else {
                // Se o elemento for uma Composição, adiciona seus elementos filhos na pilha para busca recursiva
                if (ptr instanceof Composicao) {
                    Iterator<Elemento> it = ((Composicao) ptr).elemento.iterator();
                    while (it.hasNext()) {
                        pilha.push(it.next());
                    }
                }
            }
        }
        throw new MyException("Elemento não encontrado : op->consulta");
    }

    @Override
    public Elemento excluir(String nm) throws MyException {

        Iterator<Elemento> itE = this.elemento.iterator();
        Stack<Elemento> pilha = new Stack();

        if (itE.hasNext()) {
            pilha.add(this); // adiciona o próprio objeto na pilha para iniciar a busca
        }

        Elemento ptr = this;
        // Realiza a busca até que a pilha esteja vazia
        while (!pilha.isEmpty()) {
            ptr = pilha.pop();
            if (ptr.nome.equals(nm)) { // verifica se o nome do elemento corresponde ao procurado
                if (ptr.pertenceA != null) {
                    // Remove o elemento do pai, se encontrado
                    ((Composicao) ptr.pertenceA).elemento.remove(ptr);
                }
                return ptr;
            } else {
                if (ptr instanceof Composicao) {
                    Iterator<Elemento> it = ((Composicao) ptr).elemento.iterator();
                    while (it.hasNext()) {
                        pilha.push(it.next());
                    }
                }
            }
        }
        throw new MyException("Elemento não encontrado : op->excluir");
    }

    @Override
    public void listar(int nivel) {
        tabular(nivel); // Método para criar a indentação
        System.out.println(this.nome); // Exibe o nome do elemento atual
        // Chama o método listar para cada elemento filho, incrementando o nível de indentação
        for (Elemento e : this.elemento) {
            e.listar(nivel + 1);
        }
    }
}
