package composite.modelo.produtos;

import composite.modelo.Elemento;

public class CategoriaRaiz extends Categoria {
    public CategoriaRaiz(String nm) {
        super(nm);
    }

    @Override
    public void listar(int nivel) {
        tabular(nivel); // Método para criar a indentação
        System.out.println("Categoria Raiz: " + this.nome); // Exibe o nome do elemento atual
        // Chama o método listar para cada elemento filho, incrementando o nível de indentação
        for (Elemento e : this.elemento) {
            e.listar(nivel + 1);
        }
    }
}
