public class Projeto3Decorator {
    public static void execute()
    {
        // Funcionário João
        Componente joao = new Funcionario("João", "");
        Componente a1, a2, a3;
        try{
            // Programador (80h, R$ 20),
            a1 = new Programador(80f, 20f);
            a1.aponta( joao );
            // Implantador (40h, R$ 40)
            a2 = new Implantador(40f, 40f);
            a2.aponta( a1 );
            // Treinamento de Usuário (60h, 40)
            a3 = new TreinamentoDeUsuario(60f, 40f);
            a3.aponta( a2 );

            double salario = a3.calculaSalario();
            System.out.println(a3.toString());
            System.out.println("Salario: " + salario);

        }catch(Exception e){
            System.out.println(e.getMessage());
        }

        // Funcionária Maria
        Componente maria = new Funcionario("Maria", "");
        Componente b1, b2, b3;
        try{
            // Analista de Sistema (90h, R$ 30)
            b1 = new AnalistaDeSistema(90f, 30f);
            b1.aponta( maria );
            // Testador de Software (20h, R$ 40)
            b2 = new TestadorDeSoftware(20f, 40f);
            b2.aponta( b1 );
            // Programador (70h, R$ 20)
            b3 = new Programador(70f, 20f);
            b3.aponta( b2 );

            double salario = b3.calculaSalario();
            System.out.println(b3.toString());
            System.out.println("Salario: " + salario);

        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }

    public static void main(String [] args){

        Projeto3Decorator.execute();

    }
}
