public class Pedido {

    private Estado estado;

    public Pedido() {
    }

    public String solicita(){
        this.estado = new Solicitado();
        Class classe = this.estado.getClass();
        return classe.getSimpleName();
    }

    public String cotacao(){
        this.estado = this.estado.cotacao();
        Class classe = this.estado.getClass();
        return classe.getSimpleName();
    }

    public String encomenda(){
        this.estado = this.estado.encomenda();
        Class classe = this.estado.getClass();
        return classe.getSimpleName();
    }

    public String entrega(){
        this.estado = this.estado.entrega();
        Class classe = this.estado.getClass();
        return classe.getSimpleName();
    }

    public String paga(){
        this.estado = this.estado.paga();
        Class classe = this.estado.getClass();
        return classe.getSimpleName();
    }

    public String rejeita(){
        this.estado = this.estado.rejeita();
        Class classe = this.estado.getClass();
        return classe.getSimpleName();
    }

    public String cancela(){
        this.estado = this.estado.cancela();
        Class classe = this.estado.getClass();
        return classe.getSimpleName();
    }

    public String arquiva(){
        this.estado = this.estado.arquiva();
        Class classe = this.estado.getClass();
        return classe.getSimpleName();
    }
}