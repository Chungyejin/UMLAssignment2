public class Solicitado extends Estado{

    public Solicitado() {
        super();
    }

    @Override
    public Estado cotacao() {
        return new Cotado();
    }
}
